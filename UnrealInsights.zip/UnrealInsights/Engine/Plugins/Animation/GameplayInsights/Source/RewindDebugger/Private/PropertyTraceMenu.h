﻿// Copyright Epic Games, Inc. All Rights Reserved.
#pragma once

#include "IRewindDebuggerDoubleClickHandler.h"

class FPropertyTraceMenu
{
public:
	static void Register();
};