// Copyright Epic Games, Inc. All Rights Reserved.

#include "SlateScriptingCommandsModule.h"
#include "Modules/ModuleManager.h"

void FSlateScriptingCommandsModule::StartupModule()
{
}

void FSlateScriptingCommandsModule::ShutdownModule()
{
}

IMPLEMENT_MODULE(FSlateScriptingCommandsModule, SlateScriptingCommands)
